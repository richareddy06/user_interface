
### ER-DIAGRAM

![ER diagram!](/public/images/ER_diagram.png "ER DIAGRAM")